#ifndef __WISH_U_H__
#define __WISH_U_H__

void execute_exit(int exit_value);
void execute_cd(char* newpath);
void execute_path();


#endif
